// SoupCover Macro: Content Script (v1.1.0)
// Handles shortcuts (Ctrl+M then C/S, Alt+S, Alt+C), Floating Button, & Auto-Import into soup.lmrei.id

(function () {
  if (window.__soupMacroInitialized) return;
  window.__soupMacroInitialized = true;

  const isSoupApp = window.location.hostname.includes("soup.lmrei.id") || window.location.href.includes("soup-magazine-scraper");

  let chordActive = false;
  let chordTimer = null;
  let activeToast = null;

  // ==========================================
  // HUD TOAST & NOTIFICATIONS
  // ==========================================
  function getContainer() {
    let container = document.getElementById("macro-browser-hud-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "macro-browser-hud-container";
      (document.body || document.documentElement).appendChild(container);
    }
    return container;
  }

  function showToast({ title, badge, desc, meta, isChord = false, isError = false, timeout = 3500 }) {
    try {
      const container = getContainer();

      if (activeToast) {
        activeToast.remove();
        activeToast = null;
      }

      const toast = document.createElement("div");
      toast.className = `macro-browser-toast ${isChord ? "chord-waiting" : ""} ${isError ? "error" : ""}`;

      const iconChar = isError ? "✕" : isChord ? "⌨️" : "🥣";

      toast.innerHTML = `
        <div class="icon-badge">${iconChar}</div>
        <div class="content">
          <div class="title">
            <span>${title}</span>
            ${badge ? `<span class="badge">${badge}</span>` : ""}
          </div>
          ${desc ? `<div class="desc">${desc}</div>` : ""}
          ${meta ? `<div class="meta">${meta}</div>` : ""}
        </div>
      `;

      container.appendChild(toast);
      activeToast = toast;

      if (timeout > 0) {
        setTimeout(() => {
          if (toast === activeToast) {
            toast.classList.add("closing");
            setTimeout(() => {
              toast.remove();
              if (activeToast === toast) activeToast = null;
            }, 200);
          }
        }, timeout);
      }

      return toast;
    } catch (e) {
      console.warn("[SoupCover Macro] Toast render error:", e);
    }
  }

  function cancelChord() {
    chordActive = false;
    if (chordTimer) {
      clearTimeout(chordTimer);
      chordTimer = null;
    }
    if (activeToast && activeToast.classList.contains("chord-waiting")) {
      activeToast.classList.add("closing");
      setTimeout(() => {
        if (activeToast && activeToast.classList.contains("closing")) {
          activeToast.remove();
          activeToast = null;
        }
      }, 200);
    }
  }

  function formatBytes(bytes) {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  }

  // ==========================================
  // SAFE CLIPBOARD WRITE (WITH EXECCOMMAND FALLBACK)
  // ==========================================
  async function safeCopyToClipboard(text) {
    // 1. Try modern navigator.clipboard
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch (err) {
        console.warn("[SoupCover Macro] navigator.clipboard.writeText failed, falling back to execCommand:", err);
      }
    }

    // 2. Fallback: Hidden textarea with document.execCommand
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.left = "-999999px";
      ta.style.top = "-999999px";
      ta.style.opacity = "0";
      ta.setAttribute("readonly", "");
      (document.body || document.documentElement).appendChild(ta);
      ta.focus();
      ta.select();
      const success = document.execCommand("copy");
      ta.remove();
      if (success) return true;
    } catch (err) {
      console.warn("[SoupCover Macro] execCommand fallback failed:", err);
    }

    return false;
  }

  // ==========================================
  // FETCH PAGE SOURCE
  // ==========================================
  async function fetchPageSource(mode = "raw") {
    if (mode === "raw") {
      try {
        const response = await fetch(window.location.href, {
          cache: "force-cache"
        });
        if (response.ok) {
          const text = await response.text();
          if (text && text.trim().length > 10) {
            return text;
          }
        }
      } catch (err) {
        console.warn("[SoupCover Macro] Direct fetch failed, fallback to outerHTML:", err);
      }
    }

    // Fallback: Live DOM HTML (always works on any page)
    const doctype = document.doctype
      ? new XMLSerializer().serializeToString(document.doctype) + "\n"
      : "";
    const html = document.documentElement ? document.documentElement.outerHTML : (document.body ? document.body.outerHTML : "");
    return doctype + html;
  }

  // ==========================================
  // SAFE STORAGE GET
  // ==========================================
  async function getExtensionConfig() {
    const defaults = {
      macroMode: "raw",
      showNotification: true,
      autoSendToSoup: true,
      targetMode: "rapidgator"
    };

    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        return await new Promise((resolve) => {
          chrome.storage.local.get(defaults, (data) => {
            if (chrome.runtime && chrome.runtime.lastError) {
              resolve(defaults);
            } else {
              resolve(data || defaults);
            }
          });
        });
      }
    } catch (e) {
      console.warn("[SoupCover Macro] Storage inaccessible:", e);
    }
    return defaults;
  }

  // ==========================================
  // EXECUTE MACRO (COPY & AUTO-SEND)
  // ==========================================
  async function executeMacro(options = {}) {
    cancelChord();

    try {
      const config = await getExtensionConfig();

      const shouldAutoSoup = options.forceAutoSoup !== undefined 
        ? options.forceAutoSoup 
        : config.autoSendToSoup;

      // 1. Extract HTML
      const source = await fetchPageSource(config.macroMode);
      if (!source || source.trim().length === 0) {
        throw new Error("Gagal mengambil kode HTML dari halaman ini.");
      }

      // 2. Safe Copy to clipboard (won't crash macro if clipboard write is blocked)
      const copied = await safeCopyToClipboard(source);

      // 3. Stats
      const bytes = new Blob([source]).size;
      const lines = source.split("\n").length;
      const sizeStr = formatBytes(bytes);
      const linesStr = lines.toLocaleString("id-ID");

      // 4. Save history safely
      try {
        if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get({ macroHistory: [] }, (res) => {
            const history = res.macroHistory || [];
            history.unshift({
              url: window.location.href,
              title: document.title || "Untitled",
              timestamp: new Date().toISOString(),
              size: sizeStr,
              lines: lines
            });
            chrome.storage.local.set({ macroHistory: history.slice(0, 20) });
          });
        }
      } catch (e) {
        // ignore history error
      }

      // 5. Send to SoupCover if requested
      if (shouldAutoSoup && !isSoupApp) {
        try {
          if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({
              action: "AUTO_SEND_TO_SOUP",
              data: {
                html: source,
                url: window.location.href,
                title: document.title || "Halaman Majalah",
                targetMode: config.targetMode || "rapidgator",
                timestamp: Date.now()
              }
            });
          } else {
            // Fallback: direct window.open
            window.open("https://soup.lmrei.id#auto-import", "_blank");
          }
        } catch (e) {
          window.open("https://soup.lmrei.id#auto-import", "_blank");
        }

        if (config.showNotification) {
          showToast({
            title: "Otomatis ke SoupCover ⚡",
            badge: "Ctrl+U → Ctrl+A → Ctrl+C",
            desc: "HTML disalin & dialihkan otomatis ke <strong>soup.lmrei.id</strong>!",
            meta: `Ukuran: ${sizeStr} • Baris: ${linesStr}`
          });
        }
      } else {
        if (config.showNotification) {
          showToast({
            title: copied ? "Macro Berhasil!" : "HTML Siap (Tanpa Clipboard)",
            badge: "Ctrl+U → Ctrl+A → Ctrl+C",
            desc: copied 
              ? "Seluruh kode sumber HTML berhasil disalin ke clipboard." 
              : "Kode sumber berhasil diekstrak (izin clipboard browser terbatas).",
            meta: `Ukuran: ${sizeStr} • Baris: ${linesStr}`
          });
        }
      }

      return { success: true, size: sizeStr, lines };
    } catch (err) {
      console.error("[SoupCover Macro] Execution error:", err);
      const errMsg = err && (err.message || String(err));
      showToast({
        title: "Gagal Eksekusi Macro",
        badge: "ERROR",
        desc: errMsg || "Gagal mengakses halaman.",
        isError: true
      });
      return { success: false, error: errMsg };
    }
  }

  // ==========================================
  // FLOATING ACTION BUTTON (ON NON-SOUP PAGES)
  // ==========================================
  function setupFloatingButton() {
    if (isSoupApp) return;

    getExtensionConfig().then((res) => {
      if (!res.showFab) return;
      if (document.getElementById("soupcover-fab-btn")) return;

      const fab = document.createElement("button");
      fab.id = "soupcover-fab-btn";
      fab.className = "soupcover-floating-btn";
      fab.title = "Ekstrak otomatis halaman ini ke SoupCover (Alt+S atau Ctrl+M lalu C)";
      fab.innerHTML = `
        <span class="fab-icon">🥣</span>
        <span class="fab-text">Ekstrak ke SoupCover</span>
      `;

      fab.addEventListener("click", () => {
        executeMacro({ forceAutoSoup: true });
      });

      (document.body || document.documentElement).appendChild(fab);
    });
  }

  // ==========================================
  // AUTO-IMPORT RECEIVER (ON SOUP.LMREI.ID)
  // ==========================================
  function checkAndExecuteSoupImport(data) {
    if (!isSoupApp || !data || (!data.html && !data.urls)) return;

    console.log("[SoupCover Macro] Processing auto-import data:", data.title, data.targetMode);
    const targetMode = data.targetMode || "rapidgator";

    if (typeof window.setAppMode === "function") {
      window.setAppMode(targetMode);
    }

    if (data.isBulkUrls || (data.urls && data.urls.length > 0)) {
      if (typeof window.switchRgInputTab === "function") {
        window.switchRgInputTab('urls');
      }
      const textarea = document.getElementById("rgUrlsInput");
      if (textarea) {
        textarea.value = Array.isArray(data.urls) ? data.urls.join("\n") : (data.html || "");
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
      }
      const btn = document.getElementById("btnRgExtractUrls");
      if (btn) {
        setTimeout(() => btn.click(), 350);
      }
      showToast({
        title: "Auto-Import Batch Berhasil! ⚡",
        badge: "BATCH URLS",
        desc: `Memproses ${data.urls ? data.urls.length : 'beberapa'} URL secara paralel!`,
        timeout: 4000
      });
      return;
    }

    if (targetMode === "rapidgator") {
      const textarea = document.getElementById("rgRawHtmlInput");
      const baseUrlInput = document.getElementById("rgBaseUrl");
      if (textarea) {
        textarea.value = data.html;
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
      }
      if (baseUrlInput && data.url) {
        baseUrlInput.value = data.url;
      }
      if (typeof window.extractRapidgatorFromHtml === "function") {
        setTimeout(() => window.extractRapidgatorFromHtml(), 200);
      }
    } else if (targetMode === "covers") {
      const textarea = document.getElementById("rawHtmlInput");
      const baseUrlInput = document.getElementById("baseUrlInput");
      if (textarea) {
        textarea.value = data.html;
        textarea.dispatchEvent(new Event("input", { bubbles: true }));
      }
      if (baseUrlInput && data.url) {
        baseUrlInput.value = data.url;
      }
      if (typeof window.scrapeFromHtml === "function") {
        setTimeout(() => window.scrapeFromHtml(), 200);
      }
    } else if (targetMode === "ai") {
      const aiInput = document.getElementById("aiCustomHtmlInput");
      if (aiInput) {
        aiInput.value = data.html;
      }
      if (typeof window.applyCustomHtml === "function") {
        window.applyCustomHtml();
      }
    }

    showToast({
      title: "Auto-Import Berhasil! ⚡",
      badge: targetMode.toUpperCase(),
      desc: `HTML dari <strong>${data.title}</strong> berhasil diimpor & diproses otomatis!`,
      timeout: 4000
    });
  }

  function listenForPendingImportOnSoup() {
    if (!isSoupApp) return;

    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(["pendingSoupImport"], (res) => {
          const data = res.pendingSoupImport;
          if (data && Date.now() - (data.timestamp || 0) < 60000) {
            chrome.storage.local.remove("pendingSoupImport");
            setTimeout(() => checkAndExecuteSoupImport(data), 400);
          }
        });

        chrome.runtime.onMessage.addListener((request) => {
          if (request.action === "TRIGGER_AUTO_IMPORT" && request.data) {
            chrome.storage.local.remove("pendingSoupImport");
            checkAndExecuteSoupImport(request.data);
          }
        });
      }
    } catch (e) {
      console.warn("[SoupCover Macro] Import listener error:", e);
    }
  }

  // ==========================================
  // KEYBOARD SHORTCUTS LISTENER
  // ==========================================
  window.addEventListener(
    "keydown",
    (e) => {
      const isCtrlOrCmd = e.ctrlKey || e.metaKey;

      // 1. Step 1 of Chord: Ctrl+M
      if (isCtrlOrCmd && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "m") {
        e.preventDefault();
        e.stopPropagation();

        chordActive = true;
        if (chordTimer) clearTimeout(chordTimer);

        showToast({
          title: "SoupCover Chord Aktif",
          badge: "Ctrl+M",
          desc: "Tekan <strong>C</strong> (Salin) atau <strong>S</strong> (Otomatis ke SoupCover)",
          meta: "Menunggu tombol [C] atau [S]... (2.5 detik)",
          isChord: true,
          timeout: 2500
        });

        chordTimer = setTimeout(() => {
          cancelChord();
        }, 2500);
        return;
      }

      // 2. Step 2 of Chord: C or S
      if (chordActive) {
        if (e.key.toLowerCase() === "c") {
          e.preventDefault();
          e.stopPropagation();
          executeMacro();
          return;
        } else if (e.key.toLowerCase() === "s") {
          e.preventDefault();
          e.stopPropagation();
          executeMacro({ forceAutoSoup: true });
          return;
        } else if (!["Control", "Meta", "Shift", "Alt"].includes(e.key)) {
          cancelChord();
        }
      }

      // 3. Direct Shortcuts: Alt+S (Auto Soup) or Alt+C (Copy only)
      if (e.altKey && !e.ctrlKey && !e.metaKey) {
        if (e.key.toLowerCase() === "s") {
          e.preventDefault();
          e.stopPropagation();
          executeMacro({ forceAutoSoup: true });
        } else if (e.key.toLowerCase() === "c") {
          e.preventDefault();
          e.stopPropagation();
          executeMacro({ forceAutoSoup: false });
        }
      }
    },
    true
  );

  // Runtime message receiver
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "EXECUTE_MACRO") {
          executeMacro({ forceAutoSoup: request.forceAutoSoup }).then((res) => sendResponse(res));
          return true;
        }
      });
    }
  } catch (e) {
    // ignore
  }

  // Initialization
  if (isSoupApp) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", listenForPendingImportOnSoup);
    } else {
      listenForPendingImportOnSoup();
    }
  } else {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", setupFloatingButton);
    } else {
      setupFloatingButton();
    }
  }

  console.log("[SoupCover Macro v1.1.0] Loaded. Shortcuts: [Ctrl+M lalu C/S], [Alt+S], [Alt+C]");
})();