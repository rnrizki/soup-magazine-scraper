// SoupCover Macro: Background Service Worker (Manifest V3)

chrome.runtime.onInstalled.addListener(() => {
  console.log("SoupCover Macro Extension installed successfully.");
  chrome.storage.local.set({
    macroMode: "raw", // 'raw' (Ctrl+U) or 'rendered' (live DOM)
    showNotification: true,
    autoSendToSoup: true, // Otomatis buka & ekstrak di soup.lmrei.id
    targetMode: "rapidgator", // 'rapidgator' | 'covers' | 'ai'
    showFab: true // Floating Action Button di halaman web
  });
});

// Global Shortcuts
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;

  if (command === "run-auto-soup") {
    // Force auto-send to soup.lmrei.id
    triggerMacroOnTab(tab.id, { forceAutoSoup: true });
  } else if (command === "run-source-macro") {
    // Copy only
    triggerMacroOnTab(tab.id, { forceAutoSoup: false });
  }
});

// Trigger macro in content script
async function triggerMacroOnTab(tabId, options = {}) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { 
      action: "EXECUTE_MACRO",
      forceAutoSoup: options.forceAutoSoup
    });
    if (response && response.success) {
      flashBadge("✓", "#10b981");
    }
  } catch (err) {
    console.warn("Could not message content script directly, injecting fallback:", err);
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ["content.css"]
      });
      const response = await chrome.tabs.sendMessage(tabId, { 
        action: "EXECUTE_MACRO",
        forceAutoSoup: options.forceAutoSoup
      });
      if (response && response.success) {
        flashBadge("✓", "#10b981");
      }
    } catch (e) {
      console.error("Execution failed:", e);
      flashBadge("✕", "#ef4444");
    }
  }
}

// Flash visual badge on extension icon
function flashBadge(text, color) {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
  setTimeout(() => {
    chrome.action.setBadgeText({ text: "" });
  }, 2000);
}

// Open or switch to soup.lmrei.id and trigger auto import
async function openSoupWithData(importData) {
  await chrome.storage.local.set({ pendingSoupImport: importData });

  chrome.tabs.query({ url: "*://soup.lmrei.id/*" }, (tabs) => {
    if (tabs && tabs.length > 0) {
      const soupTab = tabs[0];
      chrome.tabs.update(soupTab.id, { active: true }, () => {
        chrome.tabs.sendMessage(soupTab.id, { 
          action: "TRIGGER_AUTO_IMPORT", 
          data: importData 
        });
      });
    } else {
      chrome.tabs.create({ url: "https://soup.lmrei.id/#auto-import" });
    }
  });
}

// Message router
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "TRIGGER_ACTIVE_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].id) {
        triggerMacroOnTab(tabs[0].id, { forceAutoSoup: request.forceAutoSoup });
        sendResponse({ started: true });
      }
    });
    return true;
  }

  if (request.action === "AUTO_SEND_TO_SOUP") {
    openSoupWithData(request.data).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
});
