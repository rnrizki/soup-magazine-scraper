// SoupCover Macro Popup Logic

document.addEventListener("DOMContentLoaded", () => {
  const autoSoupBtn = document.getElementById("run-auto-soup-btn");
  const runBtn = document.getElementById("run-macro-btn");
  const statusMsg = document.getElementById("status-message");
  const autoSoupToggle = document.getElementById("auto-soup-toggle");
  const targetModeSelect = document.getElementById("target-mode-select");
  const fabToggle = document.getElementById("fab-toggle");
  const modeSelect = document.getElementById("mode-select");
  const historyList = document.getElementById("history-list");
  const clearHistoryBtn = document.getElementById("clear-history-btn");

  // 1. Load saved settings
  chrome.storage.local.get(
    { 
      macroMode: "raw", 
      autoSendToSoup: true,
      targetMode: "rapidgator",
      showFab: true,
      macroHistory: [] 
    },
    (res) => {
      if (modeSelect) modeSelect.value = res.macroMode || "raw";
      if (autoSoupToggle) autoSoupToggle.checked = res.autoSendToSoup !== false;
      if (targetModeSelect) targetModeSelect.value = res.targetMode || "rapidgator";
      if (fabToggle) fabToggle.checked = res.showFab !== false;
      renderHistory(res.macroHistory || []);
    }
  );

  // 2. Save settings on change
  if (autoSoupToggle) {
    autoSoupToggle.addEventListener("change", () => {
      chrome.storage.local.set({ autoSendToSoup: autoSoupToggle.checked });
      showStatus("Pengaturan otomasi disimpan.", "success");
    });
  }

  if (targetModeSelect) {
    targetModeSelect.addEventListener("change", () => {
      chrome.storage.local.set({ targetMode: targetModeSelect.value });
      showStatus("Target tab disimpan: " + targetModeSelect.options[targetModeSelect.selectedIndex].text, "success");
    });
  }

  if (fabToggle) {
    fabToggle.addEventListener("change", () => {
      chrome.storage.local.set({ showFab: fabToggle.checked });
      showStatus("Tombol floating diubah. Refresh halaman web untuk melihat.", "success");
    });
  }

  if (modeSelect) {
    modeSelect.addEventListener("change", () => {
      chrome.storage.local.set({ macroMode: modeSelect.value });
      showStatus("Mode HTML disimpan: " + modeSelect.options[modeSelect.selectedIndex].text, "success");
    });
  }

  // 3. Helper to trigger macro on active tab
  async function executeOnTab(forceAutoSoup) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      showStatus("Gagal: Tab browser aktif tidak ditemukan.", "error");
      return;
    }

    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "EXECUTE_MACRO",
        forceAutoSoup: forceAutoSoup
      });

      if (response && response.success) {
        const msg = forceAutoSoup
          ? `✓ Berhasil disalin & dialihkan ke soup.lmrei.id!`
          : `✓ Berhasil disalin ke clipboard! (${response.size})`;
        showStatus(msg, "success");
        refreshHistory();
      } else {
        showStatus(response?.error || "Gagal mengekstrak halaman.", "error");
      }
    } catch (err) {
      // Inject scripts if content script was not loaded yet
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"]
        });
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ["content.css"]
        });
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: "EXECUTE_MACRO",
          forceAutoSoup: forceAutoSoup
        });
        if (response && response.success) {
          showStatus("✓ Berhasil diproses!", "success");
          refreshHistory();
        }
      } catch (e) {
        showStatus("Gagal: Halaman ini membatasi eksekusi ekstensi (misal chrome://).", "error");
      }
    }
  }

  // 4. Action Buttons
  if (autoSoupBtn) {
    autoSoupBtn.addEventListener("click", async () => {
      autoSoupBtn.disabled = true;
      showStatus("Mengambil HTML & membuka SoupCover...", "");
      await executeOnTab(true);
      autoSoupBtn.disabled = false;
    });
  }

  if (runBtn) {
    runBtn.addEventListener("click", async () => {
      runBtn.disabled = true;
      showStatus("Menyalin kode sumber ke clipboard...", "");
      await executeOnTab(false);
      runBtn.disabled = false;
    });
  }

  // 5. History handling
  function refreshHistory() {
    chrome.storage.local.get({ macroHistory: [] }, (res) => {
      renderHistory(res.macroHistory || []);
    });
  }

  function renderHistory(items) {
    if (!historyList) return;
    if (items.length === 0) {
      historyList.innerHTML = '<div class="empty-history">Belum ada riwayat macro.</div>';
      return;
    }

    historyList.innerHTML = items.slice(0, 5).map((item) => {
      const timeStr = new Date(item.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      const cleanTitle = (item.title || item.url || "Untitled").replace(/</g, "&lt;");
      return `
        <div class="history-item" title="${item.url}">
          <div class="history-main">
            <span class="history-title-text">${cleanTitle}</span>
            <span class="history-time">${timeStr}</span>
          </div>
          <div class="history-sub">
            <span>${item.size || ""}</span>
            <span>•</span>
            <span>${item.lines ? item.lines.toLocaleString() + " baris" : ""}</span>
          </div>
        </div>
      `;
    }).join("");
  }

  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener("click", () => {
      chrome.storage.local.set({ macroHistory: [] }, () => {
        renderHistory([]);
        showStatus("Riwayat dibersihkan.", "success");
      });
    });
  }

  function showStatus(text, type) {
    if (!statusMsg) return;
    statusMsg.innerText = text;
    statusMsg.className = `status-msg ${type}`;
    statusMsg.classList.remove("hidden");
    if (type === "success") {
      setTimeout(() => {
        statusMsg.classList.add("hidden");
      }, 3500);
    }
  }

  // 6. Tabs & Bulk URLs Scraper
  const tabActiveBtn = document.getElementById("tab-active-btn");
  const tabBulkBtn = document.getElementById("tab-bulk-btn");
  const panelActive = document.getElementById("panel-active");
  const panelBulk = document.getElementById("panel-bulk");
  const bulkUrlsTextarea = document.getElementById("bulk-urls-textarea");
  const bulkSampleBtn = document.getElementById("bulk-sample-btn");
  const runBulkExtractBtn = document.getElementById("run-bulk-extract-btn");
  const bulkStatusMsg = document.getElementById("bulk-status-message");

  if (tabActiveBtn && tabBulkBtn) {
    tabActiveBtn.addEventListener("click", () => {
      tabActiveBtn.classList.add("active");
      tabBulkBtn.classList.remove("active");
      if (panelActive) panelActive.classList.remove("hidden");
      if (panelBulk) panelBulk.classList.add("hidden");
    });

    tabBulkBtn.addEventListener("click", () => {
      tabBulkBtn.classList.add("active");
      tabActiveBtn.classList.remove("active");
      if (panelActive) panelActive.classList.add("hidden");
      if (panelBulk) panelBulk.classList.remove("hidden");
    });
  }

  if (bulkSampleBtn && bulkUrlsTextarea) {
    bulkSampleBtn.addEventListener("click", () => {
      bulkUrlsTextarea.value = "1. https://softarchive.download/books/magazines/5673671-history-war-issue-161-2026\n2. https://softarchive.download/books/magazines/5673664-cosmopolitan-uk-august-september-2026";
    });
  }

  if (runBulkExtractBtn && bulkUrlsTextarea) {
    runBulkExtractBtn.addEventListener("click", async () => {
      const text = bulkUrlsTextarea.value.trim();
      const matches = text.match(/https?:\/\/[^\s<>"')]+/gi) || [];
      const cleanUrls = [...new Set(matches.map(u => u.replace(/[\.,;]+$/, '').trim()))];

      if (cleanUrls.length === 0) {
        showBulkStatus("Masukkan setidaknya 1 link URL majalah.", "error");
        return;
      }

      showBulkStatus(`Mengirim ${cleanUrls.length} URL ke soup.lmrei.id...`, "success");
      runBulkExtractBtn.disabled = true;

      const payload = {
        isBulkUrls: true,
        urls: cleanUrls,
        html: cleanUrls.join("\n"),
        targetMode: "rapidgator",
        title: `Batch ${cleanUrls.length} Majalah`,
        timestamp: Date.now()
      };

      try {
        await chrome.runtime.sendMessage({
          action: "AUTO_SEND_TO_SOUP",
          data: payload
        });
        showBulkStatus(`✓ Dialihkan ke soup.lmrei.id! Memproses ${cleanUrls.length} URL...`, "success");
      } catch (err) {
        showBulkStatus("Gagal: " + err.message, "error");
      } finally {
        runBulkExtractBtn.disabled = false;
      }
    });
  }

  function showBulkStatus(text, type) {
    if (!bulkStatusMsg) return;
    bulkStatusMsg.innerText = text;
    bulkStatusMsg.className = `status-msg ${type}`;
    bulkStatusMsg.classList.remove("hidden");
    if (type === "success") {
      setTimeout(() => {
        bulkStatusMsg.classList.add("hidden");
      }, 4000);
    }
  }
});