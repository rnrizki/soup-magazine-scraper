# Macro Browser: Source Copier (Chrome & Edge Extension)

Ekstensi browser untuk mengeksekusi rangkaian macro otomatis:
**`Ctrl + U` (View Source) $\rightarrow$ `Ctrl + A` (Select All) $\rightarrow$ `Ctrl + C` (Copy ke Clipboard)** secara instan tanpa perlu membuka tab baru secara manual!

---

## ⌨️ Pilihan Shortcut & Cara Penggunaan

Tersedia 3 cara untuk memicu macro:

### 1. In-Page Chord: `Ctrl + M` lalu `C` (Sesuai Permintaan)
1. Buka halaman web mana pun.
2. Tekan **`Ctrl + M`** di keyboard.
3. Di pojok kanan bawah akan muncul HUD:
   ```
   ⌨️ Macro Chord Aktif: Tekan [C] untuk eksekusi Ctrl+U → Ctrl+A → Ctrl+C...
   ```
4. Tekan tombol **`C`**.
5. Seluruh kode sumber HTML halaman web langsung tersalin ke clipboard Anda!

### 2. Direct Shortcut: `Alt + C`
- Tekan **`Alt + C`** langsung di halaman web mana pun untuk menyalin source code seketika.
- *Bisa dikustomisasi di: `chrome://extensions/shortcuts`*.

### 3. Tombol Ekstensi (Popup)
- Klik ikon ekstensi ⚡ di toolbar Chrome/Edge.
- Klik tombol besar: **"Jalankan Macro Sekarang"**.

---

## 🚀 Cara Pasang di Google Chrome / Microsoft Edge

1. Buka browser **Google Chrome** atau **Microsoft Edge**.
2. Masuk ke halaman ekstensi:
   - **Chrome**: buka `chrome://extensions/`
   - **Edge**: buka `edge://extensions/`
3. Aktifkan **Developer mode** (Mode Pengembang) di pojok kanan atas.
4. Klik tombol **Load unpacked** (Muat yang belum dibongkar).
5. Pilih folder:
   ```
   /home/rnrizki/.gemini/antigravity/scratch/macro-browser-extension
   ```
   *(Atau ekstrak file `macro-browser-extension.zip` jika Anda mengunduhnya ke laptop/PC Anda).*
6. Selesai! Sematkan (*pin*) ikon ekstensi ke toolbar browser Anda.

---

## ⚙️ Fitur Tambahan di Popup
- **Mode Pilihan**:
  - `Raw Source (Persis Ctrl+U)`: Mengambil HTML murni seperti yang dikirim oleh server asli.
  - `Rendered DOM (Setelah JS)`: Mengambil struktur DOM lengkap setelah JavaScript halaman dieksekusi.
- **HUD Toast Notifikasi**: Menampilkan ukuran file (KB/MB) dan jumlah baris yang berhasil disalin.
- **Riwayat Salinan**: Menyimpan log halaman dan ukuran source yang baru saja disalin.
